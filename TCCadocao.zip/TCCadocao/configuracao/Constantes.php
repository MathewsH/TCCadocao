<?php
 define('__RAIZ__', dirname(dirname(__FILE__)));
?>